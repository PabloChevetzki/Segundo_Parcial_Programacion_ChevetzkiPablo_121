package servicio;

import java.io.*;
import java.util.*;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import modelo.CSVSerializable;

public class Zoologico<T extends Comparable<T>> {
    private List<T> inventario;

    // Constructor
    public Zoologico() {
        this.inventario = new ArrayList<>();
    }

    // Agregar un animal al inventario
    public void agregar(T animal) {
        inventario.add(animal);
    }

    // Mostrar cada elemento (para cada animal en el inventario)
    public void paraCadaElemento(Consumer<T> accion) {
        for (T animal : inventario) {
            accion.accept(animal);
        }
    }

    // Filtrar animales usando un Predicate
    public List<T> filtrar(Predicate<T> criterio) {
        List<T> filtrados = new ArrayList<>();
        for (T animal : inventario) {
            if (criterio.test(animal)) {
                filtrados.add(animal);
            }
        }
        return filtrados;
    }

    // Ordenar animales de manera natural (por id)
    public void ordenar() {
        Collections.sort(inventario);
    }

    // Ordenar animales por un Comparator (por ejemplo, por nombre o especie)
    public void ordenar(Comparator<T> comparator) {
        inventario.sort(comparator);
    }

    // Guardar el inventario en un archivo binario
    public void guardarEnArchivo(String nombreArchivo) throws IOException {
        try (ObjectOutputStream salida = new ObjectOutputStream(new FileOutputStream(nombreArchivo))) {
            salida.writeObject(inventario);
        }
    }

    // Cargar el inventario desde un archivo binario
    public void cargarDesdeArchivo(String nombreArchivo) throws IOException, ClassNotFoundException {
        try (ObjectInputStream entrada = new ObjectInputStream(new FileInputStream(nombreArchivo))) {
            inventario = (List<T>) entrada.readObject();
        }
    }

    // Guardar el inventario en un archivo CSV
    public void guardarEnCSV(String nombreArchivo) throws IOException {
    try (BufferedWriter writer = new BufferedWriter(new FileWriter(nombreArchivo))) {
        for (T animal : inventario) {
            if (animal instanceof CSVSerializable) {
                // Realizamos el casting a CSVSerializable y luego llamamos a toCSV()
                CSVSerializable csvSerializableAnimal = (CSVSerializable) animal;
                writer.write(csvSerializableAnimal.toCSV());
                writer.newLine();
            }
        }
    }
}

    // Cargar el inventario desde un archivo CSV
    public void cargarDesdeCSV(String nombreArchivo, Function<String, T> funcionCreacion) throws IOException {
        try (BufferedReader reader = new BufferedReader(new FileReader(nombreArchivo))) {
            String linea;
            while ((linea = reader.readLine()) != null) {
                T animal = funcionCreacion.apply(linea);
                agregar(animal);
            }
        }
    }
}