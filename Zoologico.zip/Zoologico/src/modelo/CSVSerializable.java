package modelo;

public interface CSVSerializable {
    String toCSV();  // Método para exportar datos a CSV
}