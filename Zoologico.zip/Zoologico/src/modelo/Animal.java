package modelo;

public class Animal implements Comparable<Animal>, CSVSerializable {
    private int id;
    private String nombre;
    private String especie;
    private TipoAlimentacion alimentacion;

    public Animal(int id, String nombre, String especie, TipoAlimentacion alimentacion) {
        this.id = id;
        this.nombre = nombre;
        this.especie = especie;
        this.alimentacion = alimentacion;
    }

    // Implementación de compareTo() para comparar por id
    @Override
    public int compareTo(Animal otroAnimal) {
        return Integer.compare(this.id, otroAnimal.id);
    }

    // Otros métodos como getNombre(), toString(), etc.

    @Override
    public String toCSV() {
        return id + "," + nombre + "," + especie + "," + alimentacion;
    }

    // Getters y setters

    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public TipoAlimentacion getAlimentacion() {
        return alimentacion;
    }
    
    public static Animal fromCSV(String linea) {
        String[] partes = linea.split(",");
        int id = Integer.parseInt(partes[0]);
        String nombre = partes[1];
        String especie = partes[2];
        TipoAlimentacion alimentacion = TipoAlimentacion.valueOf(partes[3]);
        return new Animal(id, nombre, especie, alimentacion);
    }
}


